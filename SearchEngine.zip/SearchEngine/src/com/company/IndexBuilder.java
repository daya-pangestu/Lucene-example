package com.company;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class IndexBuilder {
    private static IndexBuilder INSTANCE;
    private LuceneUtil lu = new LuceneUtil();


    //kelas singleton
    static IndexBuilder getINSTANCE() {
        if (INSTANCE == null) {
            return new IndexBuilder();
        } else {
            return INSTANCE;
        }
    }

    //konstruktor
    private IndexBuilder() {
        readCsv();
    }

    //method untuk membaca file csv yang ada
    private void readCsv() {
        File files = new File("file.csv");
        if (files.isFile()) {
            try {
                BufferedReader br = new BufferedReader(new FileReader(files));
                String line;
                List<String> documentString = new ArrayList<>();


                while ((line = br.readLine()) != null) {
                    documentString.add(line);
                }

                br.close();

                addDocument(documentString); //panggil addocument
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //method untuk menambahkan document ke mesin pencarian
    private void addDocument(List<String> strings) throws IOException {//buat document yang nantinya digunakan untuk peng indexan
        IndexWriter writer = lu.getIndexwriter();
        Document document;

        //String[] substract;
        for (String doc : strings) {
            //substract = doc.split(",", 2);

            /*System.out.println(substract[0] + " /n" + substract[1]);
            System.out.println("-------------------------------------------------------");*/
            document = new Document();
            document.add(new TextField(CONSTANT.TITLE, doc, Field.Store.YES));
            writer.addDocument(document);
        }
        writer.close();
    }
}
