package com.company;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class searchGui {
    private JButton mBtnSearch;
    private JTextField mTxtSearch;
    private JList<Object> mListResult;
    private JPanel mPanelMain;
    private JTextPane mTvPlot;

    private HashMap<String, String> mHasil = new HashMap<>();

    private searchGui() {

        mBtnSearch.addActionListener(e -> performSearch());
        mTxtSearch.addActionListener(e -> performSearch());
    }

    private void performSearch() {
        String query = mTxtSearch.getText();
        Search s = new Search();

        mTxtSearch.setText("");
        mTvPlot.setText("");

        List<String> title = new ArrayList<>(); //list untuk menampung judul dari mHasil pencarian

        s.search(query).forEach((s1, s2) -> {
                    mHasil.put(s1, s2);
                    title.add(s1);
        });

        mListResult.setListData(title.toArray());//masukan mHasil gettilte kedalam jList
        jListSelectedListener(); //panggil method
    }

    public void jListSelectedListener() {
        mListResult.addListSelectionListener(e -> { //lakukan sesuatu jika item jList diklik
            if (!e.getValueIsAdjusting()) {

                String selectedResult = mListResult.getSelectedValue().toString(); //
                System.out.println(selectedResult); //print selected item

                //loop mHasil pencarian
                mHasil.forEach((s, s2) -> {
                    if (selectedResult.equalsIgnoreCase(s)) { //jika ada dari mHasil yang sama dengan selectedresult maka tampilkan plot di bagian jTextPane
                        if (s2.length() <= 1600) {
                            mTvPlot.setText(s + "\n " + s2);
                        } else {
                            mTvPlot.setText(s + "\n " +s2.substring(0, 1600 )+"....");
                        }
                    }
                });
            }
        });
    }

    public static void main(String[] args) {

        //untuk memanggil gui
        JFrame frame = new JFrame("searchGui");
        JScrollPane jsp = new JScrollPane(new searchGui().mTvPlot);
        frame.add(jsp);
        frame.setContentPane(new searchGui().mPanelMain);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(1200,500));
        frame.pack();
        frame.setVisible(true);
    }
}
