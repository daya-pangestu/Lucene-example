package com.company;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import java.io.File;
import java.io.IOException;

public class LuceneUtil {
    //analyzer
    public Analyzer getanalizer() {
        return new EnglishAnalyzer();
    }

    //directory
    public Directory getdirectory() throws IOException {
        return FSDirectory.open(new File("plotIndex").toPath());
    }

    //indexwriter
    public IndexWriter getIndexwriter() throws IOException {
        IndexWriterConfig iwc = new IndexWriterConfig(getanalizer());
        iwc.setOpenMode(IndexWriterConfig.OpenMode.CREATE_OR_APPEND);
        return new IndexWriter(getdirectory(), iwc);
    }
}
