package com.company;

class CONSTANT{
    //field name
    public static String TITLE = "title";
    public static String CONTENT = "content";
}
